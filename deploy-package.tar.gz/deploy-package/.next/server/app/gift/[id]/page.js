(()=>{var e={};e.id=241,e.ids=[241],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},19587:(e,t)=>{"use strict";function a(e){return e.split("/").map(e=>encodeURIComponent(e)).join("/")}Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"encodeURIPath",{enumerable:!0,get:function(){return a}})},24204:(e,t,a)=>{Promise.resolve().then(a.bind(a,47776))},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},30036:(e,t,a)=>{"use strict";a.d(t,{default:()=>r.a});var s=a(49587),r=a.n(s)},33873:e=>{"use strict";e.exports=require("path")},47776:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>X});var s=a(60687),r=a(85814),l=a.n(r),i=a(29523),n=a(23546);function c({name:e,nickname:t,text:a,className:r=""}){let l=function(e){let t={Павел:"Павла",Пётр:"Петра",Лев:"Льва",Николай:"Николая",Андрей:"Андрея",Сергей:"Сергея",Алексей:"Алексея",Евгений:"Евгения",Юрий:"Юрия",Дмитрий:"Дмитрия"};if(t[e])return t[e];for(let[t,a]of Object.entries({а:"и",я:"и",ь:"и",ия:"и",га:"и",ка:"и",ла:"ы",на:"ы"}).sort((e,t)=>t[0].length-e[0].length))if(e.endsWith(t)){if("ия"===t)return e.slice(0,-2)+a;return e.slice(0,-1)+a}return/[бвгджзклмнпрстфхцчшщ]$/i.test(e)?e+"а":e}(e);return(0,s.jsxs)("div",{className:`space-y-6 ${r}`,children:[(0,s.jsx)("div",{className:"space-y-2",children:(0,s.jsxs)("div",{className:"text-label-md font-nyghtserif italic text-adaptive tracking-wider",children:["от ",(0,s.jsx)("span",{children:l}),t&&(0,s.jsxs)("span",{className:"text-text-soft-400",children:[" (@",t,")"]})]})}),(0,s.jsx)("div",{className:"text-paragraph-lg text-adaptive font-euclid md:text-paragraph-xl",children:a})]})}function d({block:e,className:t=""}){return(0,s.jsx)("div",{className:`text-adaptive ${t}`,children:(0,s.jsx)("p",{className:(e=>{switch(e){case"title":return"text-label-sm md:text-label-md font-nyghtserif italic";case"subtitle":return"text-label-xs md:text-label-sm font-nyghtserif italic";default:return"md:text-paragraph-xl text-paragraph-lg font-euclid"}})(e.style),children:"title"===e.style||"subtitle"===e.style?`(${e.content})`:e.content})})}function o({block:e,className:t=""}){let a="big"===e.style?"text-label-sm md:text-label-md font-nyghtserif":"text-paragraph-lg md:text-paragraph-xl font-euclid";return(0,s.jsxs)("div",{className:`relative ${t}`,children:[(0,s.jsx)("div",{className:"w-0.5 absolute bottom-0 left-0 top-0 bg-white"}),(0,s.jsx)("div",{className:"pl-6",children:(0,s.jsx)("blockquote",{className:`text-adaptive ${a}`,children:e.content})})]})}function x({block:e,className:t=""}){let a=e.layout||"image-center",r=(e,t,a)=>{let s="",r="";if(a)s="w-full";else switch(e){case"small":s="w-full md:w-1/3 mx-auto";break;case"medium":s="w-full md:w-2/3 mx-auto";break;default:s="w-full mx-auto"}switch(t){case"vertical":r="aspect-[3/4]";break;case"horizontal":r="aspect-[4/3]";break;default:r=""}return`${s} ${r} h-auto rounded-2xl object-cover`},l=(e,t,a)=>{if("vertical"===t)switch(e){case"large":default:return{imageCols:"md:col-span-1",textCols:"md:col-span-1"};case"medium":if(a)return{textCols:"md:col-span-2",imageCols:"md:col-span-1"};return{imageCols:"md:col-span-1",textCols:"md:col-span-2"};case"small":if(a)return{textCols:"md:col-span-3",imageCols:"md:col-span-1"};return{imageCols:"md:col-span-1",textCols:"md:col-span-3"}}switch(e){case"large":if(a)return{textCols:"md:col-span-1",imageCols:"md:col-span-2"};return{imageCols:"md:col-span-2",textCols:"md:col-span-1"};case"medium":return{imageCols:"md:col-span-1",textCols:"md:col-span-1"};case"small":if(a)return{textCols:"md:col-span-2",imageCols:"md:col-span-1"};return{imageCols:"md:col-span-1",textCols:"md:col-span-2"};default:return{imageCols:"md:col-span-2",textCols:"md:col-span-1"}}},i=({centered:t=!1})=>e.title?(0,s.jsx)("div",{className:`text-adaptive ${t?"text-center":""}`,children:(0,s.jsxs)("p",{className:"text-label-sm md:text-label-md font-nyghtserif italic",children:["(",e.title,")"]})}):null,n=({centered:t=!1})=>e.text?(0,s.jsx)("div",{className:`text-adaptive ${t?"text-center":""}`,children:(0,s.jsx)("p",{className:"text-paragraph-lg md:text-paragraph-xl font-euclid",children:e.text})}):null,c=({centered:e=!1})=>(0,s.jsxs)("div",{className:"space-y-2",children:[(0,s.jsx)(i,{centered:e}),(0,s.jsx)(n,{centered:e})]}),d=({align:t})=>{let l="";return"left"===t?l="mr-auto":"right"===t?l="ml-auto":"center"===t&&(l="mx-auto"),(0,s.jsxs)("div",{className:"w-full",children:[(0,s.jsx)("img",{src:e.url,alt:e.caption||"Фотография",className:`${r(e.size,e.orientation,"image-left"===a||"image-right"===a)} ${l}`}),e.caption&&(0,s.jsx)("div",{className:"text-center mt-4",children:(0,s.jsx)("p",{className:"text-paragraph-md font-euclid text-text-soft-400",children:e.caption})})]})};if("image-right"===a){let{textCols:a,imageCols:r}=l(e.size,e.orientation,!0),i="md:grid-cols-3";return"vertical"===e.orientation?"large"===e.size?i="md:grid-cols-2":"medium"===e.size?i="md:grid-cols-3":"small"===e.size&&(i="md:grid-cols-4"):i="medium"===e.size?"md:grid-cols-2":"md:grid-cols-3",(0,s.jsx)("div",{className:`space-y-6 ${t}`,children:(0,s.jsxs)("div",{className:`grid grid-cols-1 ${i} gap-8 items-start`,children:[(0,s.jsx)("div",{className:`space-y-6 ${a}`,children:(0,s.jsx)(c,{})}),(0,s.jsx)("div",{className:r,children:(0,s.jsx)(d,{align:"right"})})]})})}if("image-left"===a){let{imageCols:a,textCols:r}=l(e.size,e.orientation,!1),i="md:grid-cols-3";return"vertical"===e.orientation?"large"===e.size?i="md:grid-cols-2":"medium"===e.size?i="md:grid-cols-3":"small"===e.size&&(i="md:grid-cols-4"):i="medium"===e.size?"md:grid-cols-2":"md:grid-cols-3",(0,s.jsx)("div",{className:`space-y-6 ${t}`,children:(0,s.jsxs)("div",{className:`grid grid-cols-1 ${i} gap-8 items-start`,children:[(0,s.jsx)("div",{className:a,children:(0,s.jsx)(d,{align:"left"})}),(0,s.jsx)("div",{className:`space-y-6 ${r}`,children:(0,s.jsx)(c,{})})]})})}if("vertical"===e.orientation){let a="md:w-1/2";switch(e.size){case"large":default:a="md:w-1/2";break;case"medium":a="md:w-1/3";break;case"small":a="md:w-1/4"}return(0,s.jsxs)("div",{className:`space-y-6 ${t}`,children:[(0,s.jsx)(c,{centered:!0}),(0,s.jsxs)("div",{className:"w-full flex flex-col items-center",children:[(0,s.jsx)("img",{src:e.url,alt:e.caption||"Фотография",className:`w-full ${a} aspect-[3/4] h-auto rounded-2xl object-cover`}),e.caption&&(0,s.jsx)("div",{className:"text-center mt-4",children:(0,s.jsx)("p",{className:"text-paragraph-md font-euclid text-text-soft-400",children:e.caption})})]})]})}return(0,s.jsxs)("div",{className:`space-y-6 ${t}`,children:[(0,s.jsx)(c,{centered:!0}),(0,s.jsx)(d,{align:"center"})]})}function m({block:e,className:t=""}){let a=(e,t)=>{let a="";switch(t){case"vertical":a="aspect-[3/4]";break;case"horizontal":a="aspect-[4/3]";break;default:a=""}return`w-full ${a} h-auto rounded-2xl object-cover`},r=({title:e})=>e?(0,s.jsx)("div",{className:"text-adaptive",children:(0,s.jsxs)("p",{className:"text-label-sm md:text-label-md font-nyghtserif italic",children:["(",e,")"]})}):null,l=({text:e})=>e?(0,s.jsx)("div",{className:"text-adaptive",children:(0,s.jsx)("p",{className:"md:text-paragraph-xl text-paragraph-lg font-euclid",children:e})}):null,i=({title:e,text:t,layout:a})=>"text-bottom"===a?(0,s.jsxs)("div",{className:"space-y-6 md:space-y-12",children:[(0,s.jsx)(r,{title:e}),(0,s.jsx)(l,{text:t})]}):(0,s.jsxs)("div",{className:"space-y-6 md:space-y-12",children:[(0,s.jsx)(l,{text:t}),(0,s.jsx)(r,{title:e})]}),n=({image:t,index:r})=>{let l=t.layout||"text-top";return"text-bottom"===l?(0,s.jsxs)("div",{className:"space-y-3",children:[(0,s.jsx)("img",{src:t.url,alt:t.caption||`Фотография ${r+1}`,className:a(e.size,e.orientation)}),t.caption&&(0,s.jsx)("div",{className:"text-center",children:(0,s.jsx)("p",{className:"text-paragraph-sm font-euclid text-text-soft-400",children:t.caption})}),(0,s.jsx)(i,{title:t.title,text:t.text,layout:l})]}):(0,s.jsxs)("div",{className:"space-y-3",children:[(0,s.jsx)(i,{title:t.title,text:t.text,layout:l}),(0,s.jsx)("img",{src:t.url,alt:t.caption||`Фотография ${r+1}`,className:a(e.size,e.orientation)}),t.caption&&(0,s.jsx)("div",{className:"text-center",children:(0,s.jsx)("p",{className:"text-paragraph-sm font-euclid text-text-soft-400",children:t.caption})})]})};return(0,s.jsx)("div",{className:`${t}`,children:(0,s.jsx)(()=>(0,s.jsx)("div",{className:"grid grid-cols-2 gap-4 md:gap-10",children:e.images.map((e,t)=>(0,s.jsx)(n,{image:e,index:t},t))}),{})})}var p=a(43210),u=a(30036),f=a(11365);let h=(0,u.default)(async()=>{},{loadableGenerated:{modules:["components\\gift-blocks\\video-circle-block.tsx -> react-player"]},ssr:!1});function g({block:e,className:t=""}){let[a,r]=(0,p.useState)(!1),[l,i]=(0,p.useState)(!1),[n,c]=(0,p.useState)(!1),[d,o]=(0,p.useState)(!1),[x,m]=(0,p.useState)(0),[u,g]=(0,p.useState)(0),j=(0,p.useRef)(null),b=2*Math.PI*50,v=`${(x>0?u/x*100:0)/100*b} ${b}`;return(0,s.jsxs)("div",{className:`space-y-8 ${t}`,children:[(0,s.jsxs)("div",{className:"flex flex-col gap-2",children:[e.title&&(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsxs)("p",{className:"font-nyghtserif text-label-sm md:text-label-md italic",children:["(",e.title,")"]})}),e.text&&(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsx)("p",{className:`font-euclid ${"medium"===e.textSize?"text-paragraph-lg md:text-paragraph-xl":"text-paragraph-md md:text-paragraph-lg"}`,children:e.text})})]}),(0,s.jsxs)("div",{className:"flex flex-col gap-3",children:[(0,s.jsx)("div",{className:"flex justify-center",children:(0,s.jsxs)("div",{className:`relative ${(e=>{switch(e){case"small":return"w-48 h-48";case"medium":return"w-64 h-64";default:return"w-96 h-96"}})(e.size)} group cursor-pointer overflow-hidden rounded-full bg-bg-strong-950`,onClick:()=>{r(!a)},children:[(0,s.jsx)("div",{className:"absolute inset-0 rounded-full overflow-hidden",children:(0,s.jsx)(h,{ref:j,url:e.url,playing:a,muted:d,loop:e.loop,width:"100%",height:"100%",onReady:()=>c(!0),onPlay:()=>r(!0),onPause:()=>r(!1),onDuration:e=>m(e),onProgress:({playedSeconds:e})=>g(e),config:{file:{attributes:{style:{objectFit:"cover",width:"100%",height:"100%"}}}},style:{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%, -50%)",minWidth:"100%",minHeight:"100%"}})}),n&&x>0&&a&&(0,s.jsx)("div",{className:"absolute inset-0 pointer-events-none",children:(0,s.jsx)("svg",{className:"w-full h-full transform -rotate-90",viewBox:"0 0 100 100",children:(0,s.jsx)("circle",{cx:"50",cy:"50",r:"50",fill:"none",stroke:"rgba(255, 255, 255, 0.5)",strokeWidth:"2",strokeLinecap:"round",strokeDasharray:v,className:"transition-all duration-100"})})}),!a&&n&&(0,s.jsx)("button",{onClick:e=>{e.stopPropagation(),o(!d)},className:"absolute top-2 left-1/2 transform -translate-x-1/2 w-8 h-8 bg-black bg-opacity-40 rounded-full flex items-center justify-center hover:bg-opacity-80 transition-all z-10",children:d?(0,s.jsx)(f.lQ,{className:"w-4 h-4 text-white"}):(0,s.jsx)(f.v,{className:"w-4 h-4 text-white"})}),!n&&(0,s.jsx)("div",{className:"absolute inset-0 rounded-full bg-gray-200 flex items-center justify-center",children:(0,s.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-b-2"})})]})}),e.caption&&(0,s.jsx)("div",{className:"text-center",children:(0,s.jsx)("p",{className:"font-euclid text-paragraph-md text-text-soft-400",children:e.caption})})]})]})}let j=(0,u.default)(async()=>{},{loadableGenerated:{modules:["components\\gift-blocks\\video-block.tsx -> react-player"]},ssr:!1});function b({block:e,className:t=""}){let[a,r]=(0,p.useState)(!1);return(0,s.jsxs)("div",{className:`space-y-8 ${t}`,children:[(0,s.jsxs)("div",{className:"flex flex-col gap-1",children:[e.title&&(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsxs)("p",{className:"font-nyghtserif text-label-sm md:text-label-md italic",children:["(",e.title,")"]})}),e.text&&(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsx)("p",{className:`font-euclid ${"medium"===e.textSize?"text-paragraph-lg md:text-paragraph-xl":"text-paragraph-md md:text-paragraph-lg"}`,children:e.text})})]}),(0,s.jsxs)("div",{className:"flex flex-col gap-3",children:[(0,s.jsx)("div",{className:"w-full",children:(0,s.jsxs)("div",{className:(e=>{let t="";switch(e){case"small":t="md:w-1/2 w-full mx-auto";break;case"medium":t="md:w-2/3 w-full mx-auto";break;default:t="md:w-full mx-auto"}return`${t} aspect-video rounded-2xl overflow-hidden bg-black`})(e.size)+" relative",children:[!a&&(0,s.jsx)("div",{className:"absolute inset-0 flex items-center justify-center rounded-2xl bg-gray-200",children:(0,s.jsx)("div",{className:"border-blue-500 h-8 w-8 animate-spin rounded-full border-b-2"})}),(0,s.jsx)(j,{url:e.url,width:"100%",height:"100%",controls:!0,playing:e.autoplay||!1,muted:!1!==e.muted,loop:e.loop||!1,onReady:()=>r(!0),config:{file:{attributes:{controlsList:"nodownload",disablePictureInPicture:!1,style:{borderRadius:"1rem",objectFit:"cover",width:"100%",height:"100%"}}}},style:{borderRadius:"1rem",width:"100%",height:"100%"}})]})}),e.caption&&(0,s.jsx)("div",{className:"text-center",children:(0,s.jsx)("p",{className:"font-euclid text-paragraph-md text-text-soft-400",children:e.caption})})]})]})}function v({block:e,className:t=""}){let[a,r]=(0,p.useState)(!1),[l,i]=(0,p.useState)(!1),[n,c]=(0,p.useState)(0),[d,o]=(0,p.useState)(e.duration||0),x=(0,p.useRef)(null),m=(0,p.useRef)(null);return(0,s.jsxs)("div",{className:`space-y-4 ${t}`,children:[(0,s.jsxs)("div",{className:"flex flex-col gap-1",children:[e.title&&(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsxs)("p",{className:"font-nyghtserif text-label-sm md:text-label-md italic",children:["(",e.title,")"]})}),e.text&&(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsx)("p",{className:`font-euclid ${"medium"===e.textSize?"text-paragraph-lg md:text-paragraph-xl":"text-paragraph-md md:text-paragraph-lg"}`,children:e.text})})]}),(0,s.jsx)("div",{className:"flex justify-center",children:(0,s.jsx)("div",{className:"rounded-2xl p-2 max-w-lg w-full",children:(0,s.jsxs)("div",{className:"flex items-center gap-3",children:[(0,s.jsx)("button",{onClick:()=>{m.current&&(a?m.current.pause():m.current.play())},disabled:!l,className:"w-10 h-10 bg-white bg-opacity-10 rounded-full flex items-center justify-center hover:bg-opacity-20 transition-all disabled:opacity-50",children:l?a?(0,s.jsx)(f.E$,{className:"w-5 h-5 text-white"}):(0,s.jsx)(f.ud,{className:"w-5 h-5 text-white ml-0.5"}):(0,s.jsx)(f.kt,{className:"h-5 w-5 text-white"})}),(0,s.jsx)("div",{className:"flex-1",children:(0,s.jsx)("div",{ref:x,className:"w-full"})}),(0,s.jsx)("div",{className:"text-white text-paragraph-sm font-euclid min-w-[40px]",children:(e=>{let t=Math.floor(e/60),a=Math.floor(e%60);return`${t}:${a.toString().padStart(2,"0")}`})(a?n:d)})]})})})]})}var N=a(76180),y=a.n(N),w=a(30474);function k({block:e,className:t=""}){let[a,r]=(0,p.useState)(!1),[l,i]=(0,p.useState)(!1),[n,c]=(0,p.useState)(!0),[d,o]=(0,p.useState)(!1),[x,m]=(0,p.useState)(0),[u,h]=(0,p.useState)(e.duration||0),[g,j]=(0,p.useState)(0),[b,v]=(0,p.useState)(1),[N,k]=(0,p.useState)(!1),C=(0,p.useRef)(null),$=async()=>{let e=C.current;if(e&&(l||d))try{a?e.pause():await e.play()}catch(e){console.error("Ошибка воспроизведения:",e),o(!0)}};return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(y(),{id:"1b9170674254f6f4",children:".volume-slider.jsx-1b9170674254f6f4{-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;height:3px;-webkit-border-radius:1.5px;-moz-border-radius:1.5px;border-radius:1.5px;outline:none;cursor:pointer;background:#4b5563}.volume-slider.jsx-1b9170674254f6f4::-webkit-slider-thumb{-webkit-appearance:none;-moz-appearance:none;-ms-appearance:none;appearance:none;width:0;height:0;cursor:pointer}.volume-slider.jsx-1b9170674254f6f4::-moz-range-thumb{width:0;height:0;border:none;background:transparent;cursor:pointer}"}),(0,s.jsxs)("div",{className:`jsx-1b9170674254f6f4 space-y-6 ${t}`,children:[(0,s.jsxs)("div",{className:"jsx-1b9170674254f6f4 flex flex-col gap-1",children:[e.title&&(0,s.jsx)("div",{className:"jsx-1b9170674254f6f4 text-center text-adaptive",children:(0,s.jsxs)("p",{className:"jsx-1b9170674254f6f4 font-nyghtserif text-label-sm md:text-label-md italic",children:["(",e.title,")"]})}),e.text&&(0,s.jsx)("div",{className:"jsx-1b9170674254f6f4 text-center text-adaptive",children:(0,s.jsx)("p",{className:`jsx-1b9170674254f6f4 font-euclid ${"medium"===e.textSize?"text-paragraph-lg md:text-paragraph-xl":"text-paragraph-md md:text-paragraph-lg"}`,children:e.text})})]}),(0,s.jsx)("div",{className:"jsx-1b9170674254f6f4 flex justify-center",children:(0,s.jsxs)("div",{className:"jsx-1b9170674254f6f4 bg-neutral-900 rounded-xl px-4 py-2 w-full max-w-xl",children:[(0,s.jsxs)("div",{className:"jsx-1b9170674254f6f4 flex items-center gap-3",children:[(0,s.jsxs)("div",{onClick:$,className:"jsx-1b9170674254f6f4 relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 group cursor-pointer",children:[(0,s.jsx)(w.default,{src:e.coverUrl,alt:`${e.trackName} - ${e.artist}`,fill:!0,className:"object-cover",sizes:"48px"}),(0,s.jsx)("div",{className:"jsx-1b9170674254f6f4 absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center",children:(0,s.jsxs)("div",{className:`jsx-1b9170674254f6f4 w-8 h-8 rounded-full bg-neutral-900 bg-opacity-60 flex items-center justify-center transition-all duration-200 relative overflow-hidden group/button ${n||d?"opacity-100":"opacity-0 group-hover:opacity-100"}`,children:[(0,s.jsx)("div",{className:"jsx-1b9170674254f6f4 absolute inset-0 bg-white opacity-0 group-hover/button:opacity-20 transition-opacity duration-200 rounded-full pointer-events-none"}),(0,s.jsx)("div",{className:"jsx-1b9170674254f6f4 relative z-10",children:d?(0,s.jsx)(f.IJ,{className:"w-5 h-5 text-white"}):n||!l?(0,s.jsx)(f.kt,{className:"w-5 h-5 border-white"}):a?(0,s.jsx)(f.E$,{className:"w-5 h-5 text-white"}):(0,s.jsx)(f.ud,{className:"w-5 h-5 text-white ml-0.5"})})]})})]}),(0,s.jsxs)("div",{className:"jsx-1b9170674254f6f4 flex justify-between w-full",children:[(0,s.jsxs)("div",{className:"jsx-1b9170674254f6f4 flex flex-col gap-1 min-w-0",children:[(0,s.jsx)("h3",{className:"jsx-1b9170674254f6f4 font-euclid text-paragraph-md font-medium text-white truncate",children:e.trackName}),(0,s.jsx)("p",{className:"jsx-1b9170674254f6f4 font-euclid text-paragraph-sm text-gray-400 truncate",children:e.artist})]}),(0,s.jsxs)("div",{className:"jsx-1b9170674254f6f4 flex items-center gap-2 flex-shrink-0",children:[(0,s.jsx)("button",{onClick:()=>{k(!N)},title:N?"Включить звук":"Отключить звук",className:"jsx-1b9170674254f6f4 text-neutral-300 hover:text-white transition-colors",children:N||0===b?(0,s.jsx)(f.lQ,{className:"w-5 h-5"}):(0,s.jsx)(f.v,{className:"w-5 h-5"})}),(0,s.jsx)("input",{type:"range",min:"0",max:"1",step:"0.05",value:N?0:b,onChange:e=>{let t=parseFloat(e.target.value);v(t),t>0&&k(!1)},style:{background:`linear-gradient(to right, #ffffff 0%, #ffffff ${(N?0:b)*100}%, #4b5563 ${(N?0:b)*100}%, #4b5563 100%)`},className:"jsx-1b9170674254f6f4 volume-slider w-16"})]})]})]}),(0,s.jsx)("audio",{ref:C,src:e.url,preload:"metadata",crossOrigin:"anonymous",className:"jsx-1b9170674254f6f4"})]})})]})]})}function C({block:e,className:t=""}){let a=e.images.slice(0,6),r=({image:e,index:t})=>(0,s.jsxs)("div",{className:"space-y-2",children:[(0,s.jsx)("img",{src:e.url,alt:e.caption||`Изображение ${t+1}`,className:"aspect-square w-full rounded-2xl object-cover"}),e.caption&&(0,s.jsx)("div",{className:"text-center",children:(0,s.jsx)("p",{className:"font-euclid text-paragraph-sm text-text-soft-400",children:e.caption})})]});return(0,s.jsxs)("div",{className:`space-y-8 ${t}`,children:[(0,s.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,s.jsx)(()=>e.title?(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsx)("h3",{className:"font-nyghtserif text-label-sm md:text-label-md italic",children:e.title})}):null,{}),(0,s.jsx)(()=>{if(!e.text)return null;let t="medium"===e.textSize?"text-paragraph-lg md:text-paragraph-xl":"text-paragraph-md md:text-paragraph-lg";return(0,s.jsx)("div",{className:"text-center text-adaptive",children:(0,s.jsx)("p",{className:`${t} font-euclid`,children:e.text})})},{})]}),(0,s.jsx)("div",{className:`grid ${(()=>{let t=e.images.length;return t<=2?"grid-cols-2":t<=3?"grid-cols-2 md:grid-cols-3":t<=4?"grid-cols-2 md:grid-cols-2":t<=6?"grid-cols-2 md:grid-cols-3":"grid-cols-2 md:grid-cols-3"})()} gap-2 md:gap-6`,children:a.map((e,t)=>(0,s.jsx)(r,{image:e,index:t},t))})]})}function $({content:e,memoryPhoto:t,className:a="",gift:r}){let l=(e,t)=>{let a=`block-${t}`,r="mb-12";switch(e.type){case"text":return(0,s.jsx)(d,{block:e,className:r},a);case"quote":return(0,s.jsx)(o,{block:e,className:r},a);case"image":return(0,s.jsx)(x,{block:e,className:r},a);case"two-images":return(0,s.jsx)(m,{block:e,className:r},a);case"video-circle":return(0,s.jsx)(g,{block:e,className:r},a);case"video":return(0,s.jsx)(b,{block:e,className:r},a);case"audio-message":return(0,s.jsx)(v,{block:e,className:r},a);case"music":return(0,s.jsx)(k,{block:e,className:r},a);case"gallery":return(0,s.jsx)(C,{block:e,className:r},a);default:return null}},i=r?.author||e.metadata?.senderName,n=r?.nickname?r.nickname:void 0,p=e.metadata?.description||"С днем рождения!";return(0,s.jsxs)("div",{className:`space-y-20 ${a}`,children:[i&&(0,s.jsx)(c,{name:i,nickname:n,text:p,className:"mb-16"}),e.blocks.map((e,t)=>l(e,t))]})}function R({opacity:e=10,className:t=""}){return(0,s.jsx)("div",{className:`pointer-events-none fixed inset-0 z-10 ${t}`,style:{backgroundImage:'url("/noise.gif")',backgroundSize:"auto",backgroundRepeat:"repeat",opacity:e/100,width:"100%",height:"100%"}})}var S=a(56208),P=a(16189);let z=`
  .dice-container {
    display: grid;
    place-items: center;
    width: 400px;
    padding: 60px 0 40px;
  }
  
  .dice {
    position: relative;
    width: 100px;
    height: 100px;
    transform-style: preserve-3d;
    transition: 1s ease;
  }
  
  /* Больший размер кубика для главной страницы */
  .main-dice-container .dice-container {
    width: 500px;
    padding: 80px 0 60px;
  }
  
  .main-dice-container .dice {
    width: 200px;
    height: 200px;
  }
  
  /* Увеличиваем смещение граней для большего кубика */
  .main-dice-container .front {
    transform: translateZ(100px);
  }
  
  .main-dice-container .back {
    transform: rotateX(180deg) translateZ(100px);
  }
  
  .main-dice-container .top {
    transform: rotateX(90deg) translateZ(100px);
  }
  
  .main-dice-container .bottom {
    transform: rotateX(-90deg) translateZ(100px);
  }
  
  .main-dice-container .right {
    transform: rotateY(90deg) translateZ(100px);
  }
  
  .main-dice-container .left {
    transform: rotateY(-90deg) translateZ(100px);
  }
  
  /* Стилизация граней для главной страницы */
  .main-dice-container .face {
    border-radius: 30px;
    border-width: 8px;
  }
  
  .main-dice-container .face::before {
    border-radius: 30px;
  }
  
  @keyframes rolling {
    50% {
      transform: rotateX(1080deg) rotateY(720deg);
    }
  }
  
  .face {
    position: absolute;
    width: 100%;
    height: 100%;
    border-radius: 20px;
    border: 5px solid #f6f3f0;
    transform-style: preserve-3d;
    background: linear-gradient(145deg, #dddbd8, #fff);
    display: flex;
    align-items: center;
    justify-content: center;
  }
  
  .face::before {
    position: absolute;
    content: '';
    width: 100%;
    height: 100%;
    border-radius: 20px;
    background: #f6f3f0;
    transform: translateZ(-1px);
  }
  
  .face img {
    width: 60%;
    height: 60%;
    object-fit: contain;
    z-index: 10;
  }
  
  .front {
    transform: translateZ(50px);
  }
  
  .back {
    transform: rotateX(180deg) translateZ(50px);
  }
  
  .top {
    transform: rotateX(90deg) translateZ(50px);
  }
  
  .bottom {
    transform: rotateX(-90deg) translateZ(50px);
  }
  
  .right {
    transform: rotateY(90deg) translateZ(50px);
  }
  
  .left {
    transform: rotateY(-90deg) translateZ(50px);
  }
  
  .roll-button {
    cursor: pointer;
    color: #b33951;
    margin-top: 60px;
    padding: 6px 12px;
    border-radius: 3px;
    font-weight: 700;
    font-size: 16px;
    border: 2px solid #b33951;
    transition: .4s;
  }
  
  .roll-button:hover {
    color: #fff;
    background: #b33951;
  }
  
  .roll-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`,_=({onRollComplete:e,visible:t=!0,isAutoRolling:a=!1})=>{let[r,l]=(0,p.useState)(!1),i=(0,p.useRef)(null);(0,p.useEffect)(()=>{a&&!r&&n()},[a]);let n=()=>{if(r)return;l(!0);let t=Math.floor(6*Math.random())+1;i.current&&(i.current.style.animation="rolling 6s cubic-bezier(0.165, 0.84, 0.44, 1)",setTimeout(()=>{if(i.current){switch(t){case 1:i.current.style.transform="rotateX(0deg) rotateY(0deg)";break;case 6:i.current.style.transform="rotateX(180deg) rotateY(0deg)";break;case 2:i.current.style.transform="rotateX(-90deg) rotateY(0deg)";break;case 5:i.current.style.transform="rotateX(90deg) rotateY(0deg)";break;case 3:i.current.style.transform="rotateX(0deg) rotateY(90deg)";break;case 4:i.current.style.transform="rotateX(0deg) rotateY(-90deg)"}i.current.style.animation="none",setTimeout(()=>{l(!1),e&&e(t)},500)}},6050))};return t?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)("style",{children:z}),(0,s.jsx)("div",{className:"dice-container",children:(0,s.jsxs)("div",{className:"dice",ref:i,children:[(0,s.jsx)("div",{className:"face front",children:(0,s.jsx)("img",{src:"/1.svg",alt:"1"})}),(0,s.jsx)("div",{className:"face back",children:(0,s.jsx)("img",{src:"/6.svg",alt:"6"})}),(0,s.jsx)("div",{className:"face top",children:(0,s.jsx)("img",{src:"/2.svg",alt:"2"})}),(0,s.jsx)("div",{className:"face bottom",children:(0,s.jsx)("img",{src:"/5.svg",alt:"5"})}),(0,s.jsx)("div",{className:"face right",children:(0,s.jsx)("img",{src:"/3.svg",alt:"3"})}),(0,s.jsx)("div",{className:"face left",children:(0,s.jsx)("img",{src:"/4.svg",alt:"4"})})]})})]}):null},E=`
  .dice-page-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 100;
    background-color: white;
  }
  
  .dice-wrapper {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 40;
    padding: 100px;
  }
  
  /* Больший размер кубика для страницы подарка */
  .dice-wrapper .dice-container {
    width: 500px;
    padding: 80px 0 60px;
  }
  
  .dice-wrapper .dice {
    width: 200px;
    height: 200px;
  }
  
  /* Увеличиваем смещение граней для большего кубика */
  .dice-wrapper .front {
    transform: translateZ(100px);
  }
  
  .dice-wrapper .back {
    transform: rotateX(180deg) translateZ(100px);
  }
  
  .dice-wrapper .top {
    transform: rotateX(90deg) translateZ(100px);
  }
  
  .dice-wrapper .bottom {
    transform: rotateX(-90deg) translateZ(100px);
  }
  
  .dice-wrapper .right {
    transform: rotateY(90deg) translateZ(100px);
  }
  
  .dice-wrapper .left {
    transform: rotateY(-90deg) translateZ(100px);
  }
  
  /* Стилизация граней для страницы подарка */
  .dice-wrapper .face {
    border-radius: 30px;
    border-width: 8px;
  }
  
  .dice-wrapper .face::before {
    border-radius: 30px;
  }
`,O=({onComplete:e,giftId:t})=>{let[a,r]=(0,p.useState)(!1),[l,i]=(0,p.useState)(!t),n=(0,p.useRef)(null);(0,p.useEffect)(()=>{t&&(async()=>{try{let e=await fetch(`/api/gifts/${t}`),a=await fetch(`/api/gift-content/${t}`);e.ok&&a.ok&&(console.log("Gift data and content preloaded successfully"),i(!0))}catch(e){console.error("Error preloading gift data:",e),i(!0)}})()},[t]),(0,p.useEffect)(()=>{n.current&&S.Ay.fromTo(n.current,{y:window.innerHeight/2+200,opacity:0,scale:.3},{y:0,opacity:1,scale:1,duration:1.2,ease:"power1.out",onComplete:()=>{setTimeout(()=>{r(!0)},100)}})},[]);let c=()=>{setTimeout(()=>{n.current&&S.Ay.to(n.current,{y:100,opacity:0,scale:.5,duration:.5,ease:"power3.in",onComplete:()=>{e()}})},800)};return(0,s.jsxs)("div",{className:"dice-page-container",children:[(0,s.jsx)("style",{children:E}),(0,s.jsx)("div",{ref:n,className:"dice-wrapper",children:(0,s.jsx)(_,{onRollComplete:e=>{if(console.log("Dice roll result:",e),r(!1),l)c();else{let e=setInterval(()=>{l&&(clearInterval(e),c())},100);setTimeout(()=>{clearInterval(e),c()},1e3)}},isAutoRolling:a})})]})};var D=a(93246),T=a(40565),M=a(98468),Y=a(23286),Z=a(94773);function X(){var e;let t=function(e){let[t,a]=(0,p.useState)(!1);return t}(0),{giftsDate:a}=(0,Z.Zj)(),r=(0,P.useParams)().id,c="home"===(0,P.useSearchParams)().get("from"),{data:d,isLoading:o,error:x,refetch:m}=(0,D.sw)(r),{isAuthenticated:u,isLoading:f}=(0,T.A)();(0,p.useRef)(u);let[h,g]=(0,p.useState)(c),[j,b]=(0,p.useState)(!c),v=(0,p.useRef)(null),N=(0,p.useRef)(null),y=(0,p.useRef)(null),w=(0,p.useRef)(null),k=(0,p.useRef)(null),C=(0,p.useRef)(null),S=(0,p.useRef)(null),z=(0,p.useRef)(null),_=(0,p.useRef)(null),E=(0,p.useRef)(null),X=(0,p.useRef)(null),I=(0,p.useRef)(null),A=(0,p.useRef)(null),F=(0,p.useRef)(null);if(x)return(0,s.jsx)("div",{className:"flex min-h-screen items-center justify-center p-4",children:(0,s.jsxs)("div",{className:"text-center",children:[(0,s.jsx)("h2",{className:"font-founders text-title-h2",children:"ERROR"}),(0,s.jsx)("p",{className:"mt-4 font-styrene text-paragraph-md font-bold uppercase",children:"Couldn't upload gift data"}),(0,s.jsx)("div",{className:"mt-8",children:(0,s.jsx)(i.b,{asChild:!0,children:(0,s.jsx)(l(),{href:"/",children:"Go Home"})})})]})});if(o||f||!d)return(0,s.jsx)(M.l,{});let{gift:G,content:q}=d;if(!G)return(0,s.jsx)("div",{className:"flex min-h-screen items-center justify-center p-4",children:(0,s.jsxs)("div",{className:"text-center",children:[(0,s.jsx)("h2",{className:"font-founders text-title-h2",children:"ERROR"}),(0,s.jsx)("p",{className:"mt-4 font-styrene text-paragraph-md font-bold uppercase",children:"Couldn't upload gift data"}),(0,s.jsx)("div",{className:"mt-8",children:(0,s.jsx)(i.b,{asChild:!0,children:(0,s.jsx)(l(),{href:"/",children:"Go Home"})})})]})});let L=d.memoryPhoto,H=(e=G.openDate,!!a&&a>=new Date(e));return(0,s.jsxs)("div",{className:"relative bg-bg-white-0",children:[h&&(0,s.jsx)(O,{onComplete:()=>{g(!1),b(!0)}}),!H&&(0,s.jsxs)("main",{className:"min-h-screen flex flex-col items-center justify-center relative overflow-hidden bg-bg-strong-950 text-adaptive dark-container",children:[(0,s.jsx)(R,{opacity:30}),(0,s.jsxs)("div",{className:"z-20 px-4 py-16 flex flex-col items-center justify-center text-center",children:[(0,s.jsx)("h1",{className:"font-founders text-title-h3 md:text-title-h2 uppercase mb-4 text-adaptive",children:"Shhh.."}),(0,s.jsx)("p",{className:"font-styrene text-paragraph-md font-bold uppercase mb-8 text-adaptive",children:"I open at midnight sharp"})]})]}),H&&j&&(0,s.jsxs)("main",{ref:v,className:"relative min-h-screen bg-bg-white-0 opacity-0",children:[(0,s.jsxs)("div",{className:"flex flex-col gap-2 py-24 text-center font-founders",children:[(0,s.jsxs)("h1",{ref:N,className:"text-title-h4",children:["YOUR GIFT ",(0,s.jsx)("br",{})," OF THE DAY"]}),(0,s.jsxs)("div",{ref:y,className:"text-title-h5",children:["(",G.number,")"]})]}),(0,s.jsxs)("div",{className:"flex flex-col items-center justify-center gap-4 px-4",children:[(0,s.jsxs)("div",{ref:w,className:"mx-auto max-w-xs text-center font-nyghtserif text-label-md italic sm:max-w-md md:max-w-lg md:text-label-lg",children:["“",G.englishDescription,"”"]}),(0,s.jsxs)("div",{className:"mx-auto flex w-full max-w-[280px] flex-col items-center gap-3 sm:max-w-[320px] sm:gap-4",children:[(0,s.jsx)("div",{ref:k,className:"aspect-square w-full overflow-hidden rounded-2xl",children:(0,s.jsx)("img",{src:G.hintImageUrl,alt:G.hintText||"Gift hint image",className:"h-full w-full object-cover"})}),(0,s.jsx)("p",{ref:C,className:"text-center font-styrene text-paragraph-sm font-bold uppercase md:text-paragraph-md md:font-bold",children:G.hintText})]})]}),G.code&&u&&(0,s.jsxs)("div",{className:"flex flex-col items-center gap-3 px-4 pt-24 text-center sm:gap-4 sm:pt-20 md:pt-24",children:[(0,s.jsx)("p",{ref:S,className:"mx-auto max-w-[300px] font-styrene text-paragraph-sm font-bold uppercase sm:max-w-[380px] md:max-w-[440px] md:text-paragraph-md md:font-bold lg:font-bold",children:G.codeText}),(0,s.jsx)("div",{ref:z,className:"font-founders text-title-h4 uppercase",children:G.code}),(()=>{let e=new Date(G.openDate),t=new Date(Y.H6.TARGET_DATE);return e.getFullYear()===t.getFullYear()&&e.getMonth()===t.getMonth()&&e.getDate()===t.getDate()})()&&(0,s.jsxs)("div",{ref:F,className:"mt-6 flex flex-col items-center gap-3",children:[(0,s.jsx)("p",{className:"font-styrene text-paragraph-sm font-bold uppercase md:text-paragraph-md md:font-bold",children:"Solve the main cipher"}),(0,s.jsx)(i.b,{asChild:!0,children:(0,s.jsx)(l(),{href:"/cipher",children:"Open"})})]})]}),G.code&&!u&&(0,s.jsxs)("div",{className:"flex flex-col items-center gap-3 px-4 pt-16 text-center sm:gap-5 sm:pt-20 md:pt-24",children:[(0,s.jsx)("p",{ref:S,className:"mx-auto max-w-[300px] font-styrene text-paragraph-sm font-bold uppercase sm:max-w-[380px] md:max-w-[440px] md:text-paragraph-md md:font-bold lg:font-bold",children:G.codeText}),(0,s.jsx)("div",{ref:z,className:"select-none bg-bg-strong-950 px-4 font-founders text-title-h4 uppercase text-bg-strong-950",children:"SECRET CODE"}),(()=>{let e=new Date(G.openDate),t=new Date(Y.H6.TARGET_DATE);return e.getFullYear()===t.getFullYear()&&e.getMonth()===t.getMonth()&&e.getDate()===t.getDate()})()&&(0,s.jsxs)("div",{ref:F,className:"mt-6 flex flex-col items-center gap-3",children:[(0,s.jsx)("p",{className:"font-styrene text-paragraph-sm font-bold uppercase md:text-paragraph-md md:font-bold",children:"Solve the main cipher"}),(0,s.jsx)(i.b,{asChild:!0,children:(0,s.jsx)(l(),{href:"/cipher",children:"Open"})})]})]}),(0,s.jsx)("span",{ref:_,className:"mb-6 mt-16 flex items-center justify-center font-nyghtserif text-label-lg text-adaptive sm:text-label-xl md:mb-20 md:mt-20",children:"***"}),(0,s.jsx)("div",{ref:E,className:"dark-container bg-bg-strong-950 px-4 py-12 text-adaptive sm:px-6 sm:py-14 md:py-16",children:(0,s.jsx)("div",{className:"mx-auto max-w-sm sm:max-w-2xl md:max-w-3xl lg:max-w-4xl",children:G.isSecret&&!u?(0,s.jsx)("div",{className:"text-center",children:(0,s.jsx)("p",{className:"mx-auto max-w-[290px] font-founders text-title-h4 uppercase text-adaptive md:max-w-[460px] md:text-title-h3",children:"Oops, only Lesya sees this content"})}):q&&(0,s.jsx)($,{content:q,memoryPhoto:L,className:"max-w-none",gift:G})})}),(0,s.jsxs)("div",{className:"dark-container flex flex-col items-center gap-6 bg-bg-strong-950 px-4 pb-16 pt-12 text-center text-adaptive sm:gap-8 sm:pb-20 sm:pt-16 md:gap-10 md:pb-28 md:pt-20",children:[(0,s.jsx)("span",{className:"font-nyghtserif text-adaptive sm:text-label-lg md:text-label-xl",children:"***"}),(0,s.jsxs)("h2",{ref:X,className:"font-founders text-title-h4 text-adaptive",children:["THE MEMORY ",(0,s.jsx)("br",{})," IS UNLOCKED"]}),L&&(0,s.jsx)("div",{ref:I,className:"mx-auto flex w-full items-center justify-center",children:(0,s.jsx)(l(),{href:"/gallery",className:"flex items-center justify-center transition-all",children:(0,s.jsx)(n.v,{memoryPhoto:L,isRevealed:!0,openDate:G.openDate,size:t?"small":"medium"})})}),(0,s.jsx)("div",{ref:A,className:"mt-2 sm:mt-4",children:(0,s.jsx)(l(),{href:"/gallery",children:(0,s.jsx)(i.b,{children:"to the gallery"})})})]}),(0,s.jsx)("div",{className:"h-16 bg-bg-strong-950"})]})]})}},49587:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return r}});let s=a(14985)._(a(64963));function r(e,t){var a;let r={};"function"==typeof e&&(r.loader=e);let l={...r,...t};return(0,s.default)({...l,modules:null==(a=l.loadableGenerated)?void 0:a.modules})}("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},53475:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>s});let s=(0,a(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\repositories\\\\lesya.svet\\\\src\\\\app\\\\gift\\\\[id]\\\\page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\repositories\\lesya.svet\\src\\app\\gift\\[id]\\page.tsx","default")},56780:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"BailoutToCSR",{enumerable:!0,get:function(){return r}});let s=a(81208);function r(e){let{reason:t,children:a}=e;throw Object.defineProperty(new s.BailoutToCSRError(t),"__NEXT_ERROR_CODE",{value:"E394",enumerable:!1,configurable:!0})}},60652:(e,t,a)=>{Promise.resolve().then(a.bind(a,53475))},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},64777:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"PreloadChunks",{enumerable:!0,get:function(){return n}});let s=a(60687),r=a(51215),l=a(29294),i=a(19587);function n(e){let{moduleIds:t}=e,a=l.workAsyncStorage.getStore();if(void 0===a)return null;let n=[];if(a.reactLoadableManifest&&t){let e=a.reactLoadableManifest;for(let a of t){if(!e[a])continue;let t=e[a].files;n.push(...t)}}return 0===n.length?null:(0,s.jsx)(s.Fragment,{children:n.map(e=>{let t=a.assetPrefix+"/_next/"+(0,i.encodeURIPath)(e);return e.endsWith(".css")?(0,s.jsx)("link",{precedence:"dynamic",href:t,rel:"stylesheet",as:"style"},e):((0,r.preload)(t,{as:"script",fetchPriority:"low"}),null)})})}},64963:(e,t,a)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0}),Object.defineProperty(t,"default",{enumerable:!0,get:function(){return d}});let s=a(60687),r=a(43210),l=a(56780),i=a(64777);function n(e){return{default:e&&"default"in e?e.default:e}}let c={loader:()=>Promise.resolve(n(()=>null)),loading:null,ssr:!0},d=function(e){let t={...c,...e},a=(0,r.lazy)(()=>t.loader().then(n)),d=t.loading;function o(e){let n=d?(0,s.jsx)(d,{isLoading:!0,pastDelay:!0,error:null}):null,c=!t.ssr||!!t.loading,o=c?r.Suspense:r.Fragment,x=t.ssr?(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(i.PreloadChunks,{moduleIds:t.modules}),(0,s.jsx)(a,{...e})]}):(0,s.jsx)(l.BailoutToCSR,{reason:"next/dynamic",children:(0,s.jsx)(a,{...e})});return(0,s.jsx)(o,{...c?{fallback:n}:{},children:x})}return o.displayName="LoadableComponent",o}},93513:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>i.a,__next_app__:()=>x,pages:()=>o,routeModule:()=>m,tree:()=>d});var s=a(65239),r=a(48088),l=a(88170),i=a.n(l),n=a(30893),c={};for(let e in n)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(c[e]=()=>n[e]);a.d(t,c);let d={children:["",{children:["gift",{children:["[id]",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,53475)),"C:\\repositories\\lesya.svet\\src\\app\\gift\\[id]\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,55524)),"C:\\repositories\\lesya.svet\\src\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.bind(a,54413)),"C:\\repositories\\lesya.svet\\src\\app\\not-found.tsx"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,65284,23)),"next/dist/client/components/unauthorized-error"]}]}.children,o=["C:\\repositories\\lesya.svet\\src\\app\\gift\\[id]\\page.tsx"],x={require:a,loadChunk:()=>Promise.resolve()},m=new s.AppPageRouteModule({definition:{kind:r.RouteKind.APP_PAGE,page:"/gift/[id]/page",pathname:"/gift/[id]",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[447,724,244,208,474,839,314,546],()=>a(93513));module.exports=s})();